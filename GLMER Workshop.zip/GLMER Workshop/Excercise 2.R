######################
#load packages
library(tidyverse) #for data manipulation
library(lme4) #for mixed effects models
library(effectsize) #for effect size
library(sjPlot) #for plots
library(report) #for reporting model outputs
library(afex) #for model comparisons
library(lmerTest) #for p-values in lme4 models
######################

#In the first example, we will refit model03 from previous exerciser and examine significance testing and
#random effects structures in mixed effects models.

ex1 <-read.csv("ex1.csv") #import data
model03 <- lme4::lmer(log(RT)~condition*cprof+(1+condition|subject)+(1+condition|item), ex1) #refit model03 with lme4

#The output of 'lme4' models does not show p-values because it is not possible to analytically derive
#degrees of freedom. One way to assess significance is to rely on t-values. If |t| > 2 --> significant

#(1) By relying on the t-values, which terms are significant in model03?
summary(model03)$coefficients

#Another way is to approximate degrees of freedom using the 'lmerTest' package.
#(2) By relying on the p-values from the lmerTest package, which terms are significant in model03?
model03_lmerTest <-lmerTest:: lmer(log(RT)~condition*cprof+(1+condition|subject)+(1+condition|item), ex1) 
summary(model03_lmerTest)

#Yet a third way is to run liklihood ratio tests using the 'anova' function. We need to construct models that
#are only minimally different and then compare their fits using the chi-square distribution. This can
#be achieved in 3 steps (corresponding to the number of fixed effects 4 minus the intercept 1).

#(3) Using likelihood ratio tests, assess if 'condition' is significant?
model03_null1 <- lmer(log(RT)~1+(1+condition|subject)+(1+condition|item), ex1) #intercept only model
model03_condition <- lmer(log(RT)~condition+(1+condition|subject)+(1+condition|item), ex1) #condition only model
anova(model03_null1,model03_condition) #focus on p-value


#(4) Using likelihood ratio tests, assess if 'cprof' is significant?
model03_condcprof <- lmer(log(RT)~condition+cprof+(1+condition|subject)+(1+condition|item), ex1) #condition+cprof
anova(model03_condition,model03_condcprof) #focus on p-value


#(5) Using likelihood ratio tests, assess if the interaction 'condition:cprof' is significant?
model03_intect <- lmer(log(RT)~condition*cprof+(1+condition|subject)+(1+condition|item), ex1) #condition:cprof
anova(model03_condcprof,model03_intect) #focus on p-value

#You may check your answers to (4), (5), and (6), using the 'mixed' function from 'afex' package:
afex::mixed(log(RT)~condition*cprof+(1+condition|subject)+(1+condition|item), data=ex1, method = 'LRT')


































############################
#Answers
#(1) 
#the intercapt,'conditionword', and 'cprof' are significant
########
#(2) 
#the intercapt,'conditionword', and 'cprof' are significant
########
#(3) 
#'conditionword' is significant
########
#(4) 
#'cprof' is significant
########
#(5) 
#the interaction 'condition:cprof' is not significant
########