library(designr)
library(psych)
library(lattice)
library(tidyverse)
library(sjPlot)
# 40 Eng subjects
design_lexc <- fixed.factor("condition", c("word", "nonword")) +
  random.factor("subject", instances = 40) + 
  random.factor("item", instances = 20) +
  random.factor(c("subject", "item"), groups = c("condition"))

design_lexc <- design.codes(design_lexc)


design_lexc %>% distinct(by=subject) %>% count() #80
design_lexc %>% distinct(by=item) %>% count() #20


design_lexc$cprof <- rep(rnorm(40, 0.89,0.05), each=80)
design_lexc$cprof<-scale(design_lexc$cprof) %>% as.numeric()

design_lexc$prof <- (0.89+(design_lexc$cprof)*0.05)*100
design_lexc$prof <-ifelse(design_lexc$prof>100, 100, design_lexc$prof)
design_lexc$prof <-ifelse(design_lexc$prof<75, 65, design_lexc$prof)
design_lexc$prof <- as.numeric(design_lexc$prof)

design_lexc$cprof <- scale(design_lexc$prof)
design_lexc$cprof <- scale(design_lexc$prof)

hist(design_lexc$prof)
describe(design_lexc$prof)
design_lexc$condition <- factor(design_lexc$condition, levels = c("nonword","word"))


design_lexc$RT <- exp(simLMM(
  formula = ~ condition*cprof+(1+condition|subject)+(1+condition|item),
  data = design_lexc,
  LMM = NULL,
  VC_sd = list(c(0.20, 0.15),c(0.05, 0.05),0.30),
  Fixef = c(6,-0.30,-0.10, 0),
  CP = c(0.10,0.10),
  empirical = F, verbose = T,
  family = "gaussian"))

hist(design_lexc$RT)
describe(design_lexc$RT)

unique(design_lexc$subject[is.nan(design_lexc$RT)])
design_lexc_2 <-design_lexc %>%
  filter(!is.nan(RT))

model04<-lmer(RT~condition*prof+(1+condition|subject)+(1+condition|item), design_lexc_2)
summary(model04)

plot_model(model04, type="pred", terms = c("condition"))+
  theme_bw()
plot_model(model04, type="pred", terms = c("prof"))+
  theme_bw()
plot_model(model04, type="pred", terms = c("prof","condition"))+
  theme_bw()

#by-subject adjustments
dotplot(ranef(model04, condVar=T))$subject

plot_model(model04, type="re")[[1]]+
  geom_hline(yintercept = 0, linetype = "dashed", color = "black")+
  labs(title = "By-subject adjustment", y="Difference from Grand Mean", x="Subject")+
  theme_bw()

#by-item adjustments
dotplot(ranef(model04, condVar=T))$item

plot_model(model04, type="re")[[2]]+
  geom_hline(yintercept = 0, linetype = "dashed", color = "black")+
  labs(title = "By-subject adjustment", y="Difference from Grand Mean", x="Subject")+
  theme_bw()

write.csv(design_lexc_2,"ex1.csv")

##########################
design_lexc_2$Acc<-rbinom(nrow(design_lexc_2), 1,0.5)
model05 <- glmer(Acc~condition*prof+(1+condition|subject)+(1+condition|item), family = "binomial",design_lexc_2)
summary(model05)
exp(summary(model05)$coefficients[,1])

design_lexc_2$condition <- factor(design_lexc_2$condition, levels = c("nonword","word"))
design_lexc_2$Acc <- simLMM(
  formula = ~ condition*cprof+(1+condition|subject)+(1+condition|item),
  data = design_lexc,
  LMM = NULL,
  VC_sd = list(c(0.30, 0.25),c(0.3, 0.2)),
  Fixef = c(2.5,.5,0.25, 0.1),
  CP = c(0.40,0.40),
  empirical = F, verbose = T,
  family = "binomial")



plot_model(model05, type="pred", terms = c("condition"))+
  theme_bw()
plot_model(model05, type="pred", terms="prof [all]")+
  theme_bw()
plot_model(model05, type="pred", terms = c("prof [all]","condition"))+
  theme_bw()

#by-subject adjustments
dotplot(ranef(model05, condVar=T))$subject

plot_model(model05, type="re")[[1]]+
  geom_hline(yintercept = 0, linetype = "dashed", color = "black")+
  labs(title = "By-subject adjustment", y="Difference from Grand Mean", x="Subject")+
  theme_bw()

#by-item adjustments
dotplot(ranef(model05, condVar=T))$item

plot_model(model05, type="re")[[2]]+
  geom_hline(yintercept = 0, linetype = "dashed", color = "black")+
  labs(title = "By-item adjustment", y="Difference from Grand Mean", x="Subject")+
  theme_bw()

summary(model05)
exp(summary(model05)$coefficients[,1])

#write.csv(design_lexc_2,"ex2.csv")

