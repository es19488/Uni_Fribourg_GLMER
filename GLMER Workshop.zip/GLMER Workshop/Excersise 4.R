######################
#load packages
library(tidyverse) #for data manipulation
library(lme4) #for mixed effects models
library(lmerTest) #for p-values in mixed effects models
library(effectsize) #for effect size
library(sjPlot) #for plots
library(report) #for reporting model outputs

######################
#As the final example (for more details on the method, see Song et al., 2020).
#we will look at a priming task to investigate morphological processing
#for bilinguals who learned English in an L2 classroom (CE group) and those who learned English 
#in a naturalistic environment (NE group). Participants were required to make a lexical decision task, 
#and the items were primed to 3 different conditions: "constituent"    "nonconstituent" "unrelated"
#here are some examples: for the target "unkindness", 
#"constituent" prime would be "kindness", nonconstituent primes would be "unkind", and unrelated would be "generous".
#the hypothesis is that if subjects decompose complex words into their constituent parts, then they
#should have faster RTs to targets preceded by "constituent" primes than those preceded by "unrelaed" primes. --> Hypothesis 1
#However, there should be no sig RT difference between targets preceded by "nonconstituent" and "unrelated" primes. --> Hypothesis 2

######################
#TASK 1
ex3 <-read.csv("ex3.csv") #load data
head(ex3) #inspect data

#Initially, we inspect the default contrasts for Group and Prime_type:
ex3$Group<-as.factor(ex3$Group) #instruct R that Group is a factor
contrasts(ex3$Group)

ex3$Prime_type<-as.factor(ex3$Prime_type) #instruct R that Prime_type is a factor
contrasts(ex3$Prime_type) #instruct R that Prime_type is a factor

#(1) Fill in the gaps to set sum contrasts for Group
contrasts(ex3$Group) <- c(....., .....)

#(2) Fill in the gaps to set contrasts for Prime_type which correspond to Hypothesis (1) and Hypothesis (2)
const_unr <- c(1/2,0,-1/2) #contrast1: constituent - unrelated (Hypothesis 1)
noncons_unr <- c(0, 1/2, -1/2) #contrast2: nonconstituent - unrelated (Hypothesis 2)
contrasts(ex3$Prime_type) <- cbind(....., .....)

#Now we fit a mixed effects model to examine the interaction between Group and Prime_type, while
#accounting for random intercept of subjects and items
model11 <- lmer(log(RT)~Group*Prime_type+(1|Participant)+(1|Item), data = ex3) #simplified to achieve convergence
summary(model11)
plot_model(model11, type = "eff", terms = c("Prime_type")) #priming to both constituents and non-constituents
plot_model(model11, type = "eff", terms = c("Group","Prime_type")) #priming to nonconst stronger in CE than in NE

#(3) Is there a significant RT difference between CE and NE in priming to constituents and nonconstituents (relative to unrelated items)?


#########
#Another useful plot (feel free to adjust it)
predicted.data <- data.frame(
  Predicted_logRT=predict(model11, type="response", re.form=~(1 | Participant) + (1 | Item)),
  Prime_type=ex3$Prime_type,
  Group=ex3$Group)

predicted.data <- predicted.data[
  order(predicted.data$Predicted_logRT, decreasing=FALSE),]

predicted.data$rank <- 1:nrow(predicted.data)

ggplot(data=predicted.data, aes(x=rank, y=Predicted_logRT)) +
  geom_point(aes(color=Prime_type), alpha=1, shape=4, stroke=2) +
  facet_grid(Group~Prime_type)+
  xlab("Index") +
  ylab("Predicted logRT")
#########


######################
#TASK 2

#We also want to fit the same model to analyse accuracy. The dependent variable accuracy involves '0' and '1'. 
#Therefore, a linear model -- which in principle has no upper and lower bounds does not capture the complexity of the data. 
#Recall the formula for a linear model: y~slope*x + intercept. In a binomial model, we transform the y variable:
#log(p/1-p) ~ slope*x + intercept, where p is the probability of an accurate response. Notice that (p/1-p)
#is the probability of an accurate response to the probability of an inaccurate response, and is also known as odds.
#So we fit our data to a binomial model to predict log-odds of accuracy -- i.e., log(p/1-p).
#Before creating the binomial model, we load the data and set the contrasts as in Task 1.

ex4 <-read.csv("ex4.csv") #load data
head(ex4) #inspect data

#set contrasts
ex4$Group<-as.factor(ex4$Group) 
ex4$Prime_type<-as.factor(ex4$Prime_type) 

contrasts(ex4$Group) <- c(1/2, -1/2)
const_unr <- c(1/2,0,-1/2) #contrast1: constituent - unrelated (Hypothesis 1)
noncons_unr <- c(0, 1/2, -1/2) #contrast2: nonconstituent - unrelated (Hypothesis 2)
contrasts(ex4$Prime_type) <- cbind(const_unr, noncons_unr)



#To create a binomial model in R, we use the glmer function and add 'family="binomial"'
model12 <- glmer(Acc~Group*Prime_type+(1|Participant)+(1|Item), family = "binomial",data = ex4) 
summary(model12)

plot_model(model12, type="pred", terms = "Group")
plot_model(model12, type="pred", terms = "Prime_type")
plot_model(model12, type="pred", terms = c("Group", "Prime_type"))

#(4) Is there a significant accuracy difference between CE and NE in priming to constituents and nonconstituents (relative to unrelated items)?

#Recall that the effects in model12 are on the log-odds scale. For example, the slope for Group is -45, which means that the difference 
#in log-odds between CE and NE is 45. This is not intuitive, so to help with the interpretation, we use the exp() function
#to estimate odds ratio:

exp(summary(model12)$coefficients[,1])

#(5) Fill in the blanks using odds ratio information.
#The odds of an accurate response by the CE is 37% of the odds of an accurate response by the NE.

#The odds of an accurate response in targets preceded by constituent primes was ....... the odds of an accurate response
#in targets preceded by unrelated primes.

#The odds of an accurate response in targets preceded by nonconstituent primes was ....... the odds of an accurate response
#in targets preceded by unrelated primes.



#########
#Another useful plot (feel free to adjust it)
predicted.data <- data.frame(
  Participant=ex4$Participant,
  probability.of.hd=predict(model12, type="response", re.form=~(1 | Participant) + (1 | Item)),
  Prime_type=ex4$Prime_type,
  Group=ex4$Group)

predicted.data <- predicted.data[
  order(predicted.data$probability.of.hd, decreasing=FALSE),]

predicted.data$rank <- 1:nrow(predicted.data)

ggplot(data=predicted.data, aes(x=rank, y=probability.of.hd)) +
  geom_point(aes(color=Prime_type), alpha=1, shape=4, stroke=2) +
  facet_grid(Group~Prime_type)+
  xlab("Index") +
  ylab("Predicted probability of getting heart disease")

#########
























































############################
#Answers
#(1) 
contrasts(ex3$Group) <- c(-1/2, 1/2)
########
#(2) 
contrasts(ex3$Prime_type) <- cbind(const_unr, noncons_unr)
#########
#(3) 
#Yes, both groups are primed to 'constituents', but only NE primed to 'nonconstituents'. (RT analysis)
#########
#(4) 
#No, both groups are primed to both 'constituents' and 'nonconstituents' (accuracy analysis)
#########
#(5) 
#The odds of an accurate response in targets preceded by constituent primes was 2.25 the odds of an accurate response
#in targets preceded by unrelated primes.

#The odds of an accurate response in targets preceded by nonconstituent primes was 2.26 the odds of an accurate response
#in targets preceded by unrelated primes.
#########