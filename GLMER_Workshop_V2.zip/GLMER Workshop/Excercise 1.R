######################
#load packages
library(tidyverse) #for data manipulation
library(lme4) #for mixed effects models
library(lmerTest) #for p-values in mixed effects models
library(effectsize) #for effect size
library(sjPlot) #for plots
library(report) #for reporting model outputs
library(performance)
######################

#In the first example, we will import data from a lexical decision task.
#Participants were presented with a series of letter strings, and they had to quickly decide 
#whether each string forms a valid word or not, while their response accuracy and reaction times (RTs)
#were being recorded. Below we only focus on reaction times. We are interested
#in the effects of condition (word vs nonword), proficiency, and their interaction.

######################
#TASK 1
#load data for Lexical Decision Task

ex1 <-read.csv("ex1.csv")
head(ex1) #inspect data

model00<-lm(RT~condition*prof, ex1) #a linear regression model to examine the effect of proficiency on reaction times (RT)
summary(model00) #to inspect the model output

#(1) How do you interpret the intercept 1299.992?

######################
#TASK 2

#To help with the interpretation, it is a good idea to center continuous predictors before entering them
#into a regression analysis. This involves subtracting the mean of a predictor variable from each individual
#score of that variable.

ex1$cprof <- ex1$prof - mean(ex1$prof) #center proficiency and store results in a new variable cprof
model01<-lm(RT~condition*cprof, ex1) #refit the same model but with centred proficiency as the predictor
summary(model01)

#to help with the interpretation, it is a good idea to visualise results.

plot_model(model01, type="pred", terms = "condition") #'word' vs. 'nonword'
plot_model(model01, type="pred", terms = "cprof") #proficiency effect
plot_model(model01, type="pred", terms = c("cprof", "condition")) #interaction

#If you want to estimates of standardised effect sizes (Cohen's d), you may want to run the 'effectsize' function'
effectsize(model01)

#(2) How do you interpret the intercept of model01? 

#(3) How do you interpret the rest of model01? You may want to run the 'report' function to check (some of) your answers.
report(model01)

#(4) Compare the output of model00 (no centering) and model01 (with centering). What is the difference and why?
summary(model00)$coefficients
summary(model01)$coefficients

######################
#TASK 3

#The previous model only included fixed effects. This is problematic, since
#our data involves repeated measures across subjects and items. We need to take this into
#account. We will construct a new model to allow for by-subject and by-item adjustments to 
#the intercept and slope. This can be achieved by adding (1+condition|subject) and 
#(1+condition|item), respectively.

model02 <- lmer(RT~condition*cprof+(1+condition|subject)+(1+condition|item), ex1)
summary(model02)

#visualise results
plot_model(model02, type="re") [1] #random effects of subject
plot_model(model02, type="re") [2] #random effects of item
plot_model(model02, type="pred", terms = "condition") #'word' vs. 'nonword'
plot_model(model02, type="pred", terms = "cprof") #proficiency effect
plot_model(model02, type="pred", terms = c("cprof", "condition")) #interaction

#(5) Focus on the random effects output of model02 and fill in the gaps:
summary(model02)$varcor #extract random effects


#average by-subject adjustment to the intercept: 104
#average by-subject adjustment to the slope: 63
#correlation between by-subject random intercept and slope: -0.30
#average by-item adjustment to the intercept: ...........
#average by-item adjustment to the slope: ...........
#correlation between by-item random intercept and slope: ...........


#(6) How do you interpret the fixed effects output of model02? Check your answers by running 'report':
summary(model02)$coefficients
report(model02)

#(7) Compare the fixed effects output of model01 and model02. What is the difference and why?
summary(model01)$coefficients
summary(model02)$coefficients


#We managed to address the lack of 'independence' assumption in model00 by including random effects
#of subjects and items. Let's check if other assumptions are met.

check_model(model02)

#posterior predictive checks show that the observed data is right-skewed, whereas the model
#predicts a random RT distribution. This discrepancy suggests that given the data,the true 
#population parameters are unlikely to be retrieved from our model --> Not good

#Influential observation: the data point '2865' has too high a leverage of the model output --> Not good!

#Normality of residuals: errors at the right end of the distribution are too high --> Not good!


#To address the above issues, we log transform 'RT' before including it in the model. This helps
#with the 'non-normality of residuals' as well as minimises the impact of influential observations.

model03 <- lmer(log(RT)~condition*cprof+(1+condition|subject)+(1+condition|item), ex1)
summary(model03)

#(8) Is model03 any better than model02 above in respecting the assumptions of linear models? Why (not)?
#to answer these questions, run model diagnostics for 'model02' and 'model03'
check_model(model02)
check_model(model03)










































############################
#Answers
#(1) 
#the intercept 1299.9921 shows predicted RT for nonwords at zero proficiency
########
#(2) 
#the intercept 441.4240 shows predicted RT for nonwords at mean proficiency
########
#(3)
#Call: lm(formula = RT ~ condition * cprof, data = ex1) --> model formula

#Residuals Min      1Q  Median      3Q     Max 
#          -401.95 -113.92  -27.93   80.04 1028.45
#This provides information about the distribution of residuals, which is assumed to be
#noral in both GLMs and GLMMs. The absolute values for 1Q and 3Q of a normal distribution
#should be roughly equal. Clearly, the assumption of normality of residuals is NOT met in model01.

#Coefficients: 
#conditionword:-107.0418 --> words are 107.0418 ms. faster than nonwords at average proficiency
#cprof: -9.6720 --> given one unit increase in average proficiency, we expect RTs for nonwords to decrease by 9.6720 ms.
#conditionword:cprof: 2.1966 --> given one unit increase in average proficiency, we expect the RT difference
#between words and nonwords (i.e., -107.0418) to increase by 2.1966. That is, for someone who has a proficiency of [mean(prof)+1], we
#expect words to be faster by (107.0418-2.1966=104.8452) ms.

#SE shows the model's uncertainty about the estimates. The higher the SE, the more uncertain the model is.
#t = estimate/SE
#p-value indicates whether the estimates are significantly different from zero.
#Multiple R-squared:  0.1678 --> the model explains 16.78% of the RT variance
#Adjusted R-squared:  0.1671 --> if accounting for the penalty due to the number of variables,
#the model explains 16.71% of the RT variance.
#F-statistic: 214.9 on 3 and 3196 DF,  p-value: < 2.2e-16 --> as the p-value is below <.05, the model explains
#a significantly larger proportion of the variance than the variance explained by an intercept-only model
########
#(4) 
#the intercept in model01 shows predicted RTs for nonwords at mean proficiency, whereas in model00 it shows
#predicted RTs for nonwords at 0 proficiency. In addition, 'conditionword' in model01 shows the predicted RT difference
#between words and nonwords at mean proficiency, whereas in model00 it shows the RT difference between words and nonwords
#at zero proficiency
########
#(5)
#average by-subject adjustment to the intercept: 104
#average by-subject adjustment to the slope: 63
#correlation between by-subject random intercept and slope: -0.30
#average by-item adjustment to the intercept: 25
#average by-item adjustment to the slope: 29
#correlation between by-item random intercept and slope: -0.63
########
#(6)
#The interpretation of intercept and slopes are exactly the same in model02 and model01 (see 3 above)
########
#(7)
#The difference in the output of model01 and model02 is in SE; model02 is more uncertain about the estimates due
#to the random effects. Since SE is larger in model02 than in model01, t- and p-values are smaller. 
#######
#(8)
#the assumption of normality of residuals is not met in model02, but it is far better in model03. Likewise, 
#no data point has too high a leverage on model03, but the data point in row 2865 heavily affects model02. Therefore,
#model03 is more robust to outliers than model02.
#######
