######################
#load packages
library(tidyverse) #for data manipulation
library(lme4) #for mixed effects models
library(lmerTest) #for p-values in mixed effects models
library(effectsize) #for effect size
library(sjPlot) #for plots
library(report) #for reporting model outputs

######################
#As the final example (for more details on the method, see Song et al., 2020).
#we will look at a priming task to investigate morphological processing
#for bilinguals who learned English in an L2 classroom (CE group) and those who learned English 
#in a naturalistic environment (NE group). Participants were required to make a lexical decision task, 
#and the items were primed to 3 different conditions: "constituent"    "nonconstituent" "unrelated"
#here are some examples: for the target "unkindness", 
#"constituent" prime would be "kindness", nonconstituent primes would be "unkind", and unrelated would be "generous".
#the hypothesis is that if subjects decompose complex words into their constituent parts, then they
#should have faster RTs to targets preceded by "constituent" primes than those preceded by "unrelaed" primes. --> Hypothesis 1
#However, there should be no sig RT difference between targets preceded by "nonconstituent" and "unrelated" primes. --> Hypothesis 2

######################
#TASK 1
ex3 <-read.csv("ex3.csv") #load data
head(ex3) #inspect data

#Hypothesis 1: RT (constituents) - RT (unrelated) < 0
#Hypothesis 2: RT (nonconstituents) - RT (unrelated) = 0
#Hypothesis 3_1: [RT (constituents) - RT (unrelated) < 0] * Group
#Hypothesis 3_2: [RT (nonconstituents) - RT (unrelated) = 0] * Group

##SET CONTRASTS
#Prime type
ex3$Prime_type <- as.factor(ex3$Prime_type)
ex3$Prime_type <- relevel(ex3$Prime_type, ref = "unrelated")
contrasts(ex3$Prime_type) <- contr.treatment(3)
contrasts(ex3$Prime_type)

#Group
ex3$Group <- as.factor(ex3$Group)
contrasts(ex3$Group) <- contr.treatment(2)
contrasts(ex3$Group)

#Run model
model11 <- lmerTest::lmer(log(RT)~Group*Prime_type+(1|Participant)+(1|Item), data = ex3)
summary(model11)$coefficients

#The intercept shows CE's predicted logRT for unrelated prime types: 7.00133337
#The slope 'Group2' shows the predicted logRT difference between CE and NE for 'unrelated': 0.033
#The slope Prime_type2 shows CE had faster logRT for 'constituents' than 'unrelated', i.e., priming to 'constituents': -0.181
#The slope Prime_type3 shows CE had faster logRT for 'nonconstituents' than 'unrelated', i.e., priming to 'nonconstituents': -0.201
#The interaction Group2:Prime_type2 shows that priming to 'constituents' was stronger among the NE (more negative): -0.068
#The interaction Group2:Prime_type3 shows that priming to 'nonconstituents' was weaker among the NE (less negative): 0.083



#However, the issue is that The contrasts are not independent. 
#Both slopes Prime_type2 and Prime_type3 compare 'unrelated' primes to other categories

#You can assess the lack of independence by:
cor(contr.treatment(3))

#Teak the hypotheses
#Hypothesis 1:  [RT (constituents)/3 +RT (nonconstituents)/3 - 2*RT (unrelated)]/3 < 0
#Hypothesis 2: [RT (constituents)/2 - RT (nonconstituents)]/2 < 0
#Hypothesis 3_1:[RT (constituents)/3 +RT (nonconstituents)/3 - 2RT (unrelated)/3] Group
#Hypothesis 3_2: [RT (constituents)/2 - RT (nonconstituents)/2] * Group


#Let's reorder the levels of Prime type to its orignal leves:
ex3$Prime_type <- factor(ex3$Prime_type, 
                         levels = c("constituent", "nonconstituent", "unrelated"))


#Now we create contrasts that are orthogonal:
#Prime type
connoncs_unr <- c(1/3,1/3,-2/3) #contrast1: const/3 + nonconst/3 - 2*unrelated/3 
const_nonconcs <- c(1/2, -1/2,0) #contrast2: const/2 - nonconst/2
contrasts(ex3$Prime_type) <- cbind(connoncs_unr, const_nonconcs)

#Group
levels(ex3$Group)
contrasts(ex3$Group) <- c(1/2,-1/2)

#Run the model again:
model11 <- lmerTest::lmer(log(RT)~Group*Prime_type+(1|Participant)+(1|Item), data = ex3)
summary(model11)$coefficients
plot_model(model11, type = "eff", terms = c("Prime_type")) 
plot_model(model11, type = "eff", terms = c("Group","Prime_type"))

#The intercept is the grand mean predicted logRT for the two groups collapsing over the different primes: 6.893
#The slope for 'Group1' is the predicted logRT difference between 'CE' and 'NE' collapsing over the different primes:  -0.038
#The slope 'Prime_typeconnoncs_unr' is the grand mean predicted logRT difference between 'related' and 'unrelated' primes: -0.187
#The slope 'Prime_typeconst_nonconcs' is the grand mean predicted logRT difference between 'constituent' and 'nonconstituent' primes: -0.056

#The interaction 'Group1:Prime_typeconnoncs_unr' the difference between 'CE' and 'NE in 
#how much they were primed to 'related' as opposed to 'unrelated' conditions: -0.008
#The interaction 'Group1:Prime_typeconst_nonconcs' the difference between 'CE' and 'NE in 
#how much they were primed to 'constituent' as opposed to 'nonconstituent' conditions: 0.151


#Nested contrasts

#Focus on NE
ex3_NE <- ex3 %>% filter(Group=="NE")
model11_NE <- lmer(log(RT)~Prime_type+(1|Participant)+(1|Item), ex3_NE)
summary(model11_NE)$coefficients

#Focus on CE
ex3_CE <- ex3 %>% filter(Group=="CE")
model11_CE <- lmer(log(RT)~Prime_type+(1|Participant)+(1|Item), ex3_CE)
summary(model11_CE)$coefficients
                                   
                                   
############################
#Accuracy Analysis
ex4 <-read.csv("ex4.csv")

#Set contrasts
#Prime type
ex4$Prime_type<-as.factor(ex4$Prime_type)
levels(ex4$Prime_type)
connoncs_unr <- c(1/3,1/3,-2/3) #contrast1: const/3 + nonconst/3 - 2*unrelated/3 
const_nonconcs <- c(1/2, -1/2,0) #contrast2: const/2 - nonconst/2
contrasts(ex4$Prime_type) <- cbind(connoncs_unr, const_nonconcs)

#Group
ex4$Group<-as.factor(ex4$Group)
levels(ex4$Group)
contrasts(ex4$Group) <- c(-1/2,+1/2)


#Fit model
model12 <- glmer(Acc~Group*Prime_type+(1|Participant)+(1|Item), 
                 family = binomial, data = ex4)
summary(model12)
plot_model(model12, type = "eff", terms = c("Prime_type")) 
plot_model(model12, type = "eff", terms = c("Group","Prime_type"))

#Odds ratio
odds_ratio<-exp(summary(model12)$coefficients[,1])
cIs <-exp(confint.merMod(model12, method="Wald")[3:8,])
cbind(odds_ratio,cIs)

#Group1: 2.700 --> the odds of NE being accurate is 2.7 times the odds of CE being accurate
#Prime_typeconnoncs_unr: 3.386 --> the odds of accuracy following 'related' primes is 3.386 times 
#the odds of accurate response following 'unrelated' primes

#Prime_typeconst_nonconcs: 0.996 --> the odds of accuracy following 'constituents' primes is 
#0.4% (1-0.996) less than the odds of accurate response following 'nonconstituent' primes, but this difference is not significant.

#Group1:Prime_typeconnoncs_unr: 0.608 --> the odds of accuracy following 'related' primes is 
#39% (1-0.608) less than the odds accuracy following 'unrelated' primes among the CE compared to the NE, but this is not significant

#Group1:Prime_typeconst_nonconcs: 0.728 --> the odds of accuracy following 'related' primes is 
#27.2% (1-0.728) less than the odds accuracy following 'unrelated' primes among the CE compared to the NE, but this is not significant
