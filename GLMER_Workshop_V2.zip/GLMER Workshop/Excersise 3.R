######################
#load packages
library(tidyverse) #for data manipulation
library(lme4) #for mixed effects models
library(lmerTest) #for p-values in mixed effects models
library(effectsize) #for effect size
library(sjPlot) #for plots
library(report) #for reporting model outputs

######################
#As another example, we are going to look SPR data. The focus of #the experiment was to examine 
#relative clause ambiguous structures, e.g.,
#the assistant of the pharmacists who was preparing the medicine* --> DP1 attachment
#the assistants of the pharmacist who was preparing the medicine* --> DP2 attachment
#This was a 2-by-2 study, crossing attachment (DP1, DP2) and context (DP1-supporting, DP2-supporting).
#Our question is whether reaction times (RTs) are different in DP1-attachment and
#DP2-attachment sentences, and whether this is influenced by context. Below we create a model
#to examine the interaction between attachment and context, while controlling for by-subject and
#by-item variability around the intercept
######################
#TASK 1
ex2 <-read.csv("ex2.csv") #load data
head(ex2) #inspect data

##### Overall, there are 4 different conditions:
#- DP1-context & DP1-attachment
#- DP1-context & DP2-attachment
#- DP2-context & DP1-attachment
#- DP2-context & DP2-attachment

#If context plays a role, we expect to observe 
#- faster RTs in congruent conditions compared to incongruent conditions (Hypothesis 1)

#Follow-ups: what is the attachment preference in a DP1-supporting context? How about in a DP2-supporting context?
#- faster RTs for DP1-attachment in a DP1-context? (Hypothesis 2)
#- faster RTs for DP2-attachment in a DP2-context (Hypothesis 3)

model03 <- lmer(RT ~ attachment*context+(1+attachment*context|subject)+ (1+attachment*context|item), ex2)
summary(model03)

#The convergence issue suggests that the output of the model is not reliable -- we should simplify the model

#(1) Simplify the models as below. Which of the following converges successfully?
model04 <- lmer(RT ~ attachment*context+(1+attachment|subject)+ (1+attachment|item), ex2) #fit the model without random effects for context
model05 <- lmer(RT ~ attachment*context+(1+context|subject)+ (1+context|item), ex2) #fit the model without random effects for attachment
model06 <- lmer(RT ~ attachment*context+(1|subject)+ (1|item), ex2) #fit the model without random slopes

#(2) How do you interpret the output of model06? Fill in the gaps.
summary(model06)$coefficients

#the intercept shows predicted RTs for DP1attachment-DP1context: 390.56
#the slope attachmentDP2 shows the RT difference between DP1attachment-DP1context and DP2attachment-DP1context: 43.88
#the slope contextDP2 shows the RT difference between DP1attachment-DP1context and DP1attachment-DP2context: -3.77
#the slope attachmentDP2:contextDP2 shows the RT difference between DP1attachment-DP1context and DP2attachment-DP2context: -48.76


#(3) Which of Hypotheses 1, 2, and 3 can we address using model06? 
#Hypothesis 2: in a DP1-context, DP1 attachment being read sig faster than DP2 attachment
######################
#Task 2

#Below we set sum contrasts to attachment and context before refitting the same model.
#This allows us to examine main and interaction effects as in a typical ANOVA analysis.

ex2$attachment <-as.factor(ex2$attachment) #instruct R that attachment is a categorical (or factor) variable
contrasts(ex2$attachment) <- c(1/2,-1/2) 
contrasts(ex2$attachment) #Note the signs (DP1 - DP2)

ex2$context <-as.factor(ex2$context) #instruct R that context is a categorical (or factor) variable
contrasts(ex2$context) <- c(1/2,-1/2) 
contrasts(ex2$context) #Note the signs (DP1 - DP2)

#Now we refit model06 to examine main and interaction effects, but with sum contrasts.
model07 <- lmer(RT ~ attachment*context+(1|subject)+ (1|item), ex2)
summary(model07)$coefficients
plot_model(model07, type="pred", terms=c("context", "attachment"))

#(4)How do you interpret the output of model07? Fill in the gaps.
summary(model07)$coefficients

#the intercept shows predicted average RTs for all conditions: 398.4
#the slope attachment1 shows the main effect of attachment: -19.50
#the slope contextDP2 shows the main effect of context: 28.15
#the slope attachment1:context1 shows the RT difference between congruent and incongruent conditions: -48.76


#Now that we can assess the interaction between attachment and context (Hypothesis 1), let's subset the data to focus
#only on DP1-context (to assess Hypothesis 2) and DP2-context separately (to assess Hypothesis 3).

ex2_DP1context <- ex2 %>% filter(context=="DP1")
model08 <- lmer(RT ~ attachment+(1|subject)+ (1|item), ex2_DP1context)
summary(model08)$coefficients

#(5) In DP1-context, what is the preferred attachment? DP1

ex2_DP1context <- ex2 %>% filter(context=="DP2")
model09 <- lmer(RT ~ attachment+(1|subject)+ (1|item), ex2_DP1context)
summary(model09)$coefficients

#(6) In DP2-context, what is the preferred attachment? no strong evidence for either DP1 or DP2

#(7)Which of Hypotheses 1, 2, and 3 can we address using model07, model08, and model09? ALL :)

######################
#Task 3

#here we use a more flexible way of creating contrasts. Recall that we are dealing with 4 conditions, 
#so total number of comparisons allowed will be 3 (1 less than number of conditions). First, we pull together
#all conditions from attachment and context under a new column. Then We create individual
#contrasts using c() command and then combine them into the contrast matrix.

ex2$condition <- interaction(ex2$attachment, ex2$context) #pull all conditions together
head(ex2)
levels(ex2$condition) #inspect levels under 'condition'

main_att <- c(1/2,-1/2,1/2,-1/2) #computes main effect of attachment (DP1-DP2)
main_contx <- c(1/2,1/2,-1/2,-1/2) #computes main effect of context (DP1-DP2)
interc <- c(1/4,-1/4,-1/4,1/4) #computes RT difference between congruent (DP1.DP1 & DP2.DP2) and incongruent conditions (DP2.DP1 & DP1.DP2)

#Note that we used (1/2) weightings for the main effects. This is because attachment and context each had 2 levels.
#Also note that we used (1/4) weightings for the interaction term. This is because calculating the interaction
#involves multiplying the weightings of individual terms --> (1/2)*(1/2) = 1/4

contrasts(ex2$condition)<-cbind(main_att, main_contx, interc) #combine the contrasts above into the contrast matrix

#(8) Compare the output of model10 and previous model07.
model10 <- lmer(RT ~ condition+(1|subject)+ (1|item), ex2)
summary(model10)$coefficients
summary(model07)$coefficients










































############################
#Answers
#(1) 
#only model06 which does not include any random slopes converges successfully
########
#(2) 
#the intercept shows predicted RTs for DP1attachment-DP1context: 390.56
#the slope attachmentDP2 shows the RT difference between DP1attachment-DP1context and DP2attachment-DP1context: 43.88
#the slope contextDP2 shows the RT difference between DP1attachment-DP1context and DP1attachment-DP2context: -3.77
#the slope attachmentDP2:contextDP2 shows the RT difference between DP1attachment-DP1context and DP2attachment-DP2context: --48.760786
########
#(3) 
#the sloe attachmentDP2 shows the RT difference between DP1- and DP2-attachment in a DP1-supporting context (i.e., Hypothesis 1)
########
#(4) 
#the intercept shows predicted average RTs for all conditions: 398.4
#the slope attachment1 shows the main effect of attachment: -19.50
#the slope contextDP2 shows the main effect of context: 28.15
#the slope attachment1:context1 shows the RT difference between congruent and incongruent conditions: -48.76079
########
#(5) 
#the slope for attachment in model08 (which includes only DP1-context conditions) shows a preference for DP1 than DP2 attachment.
########
#(6) 
#the slope for attachment in model09 (which includes only DP2-context conditions) shows no significant RT difference between
#DP1 and DP2 attachment.
########
########
#(7) 
#the interaction term in model07 shows the RT difference in congruent and noncongruent conditions (Hypothesis 1), and 
#the slope for attachment in model08 and model09 show the RT difference between DP1 and DP2 attachment in 
#a DP1-context and Dp2-context, respectively.
########
#(8) 
#outputs are identical -- use +/-1/2 weightings for main effects and 1/4 for interaction (i.e., 1/2 x 1/2)
########